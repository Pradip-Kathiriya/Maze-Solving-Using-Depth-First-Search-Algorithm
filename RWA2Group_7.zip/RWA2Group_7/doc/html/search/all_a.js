var searchData=
[
  ['turn_5fleft_40',['turn_left',['../classrwa2_1_1_mouse.html#a5748e94e740432c334d15364fb476919',1,'rwa2::Mouse']]],
  ['turn_5fright_41',['turn_right',['../classrwa2_1_1_mouse.html#ac929127d86fc4a41d1e216968b1dae20',1,'rwa2::Mouse']]],
  ['turnleft_42',['turnLeft',['../class_a_p_i.html#af04ee9209026f2a6e1c502e6c900573f',1,'API']]],
  ['turnright_43',['turnRight',['../class_a_p_i.html#a4b5aaf5e3e061474d84191ab9ee05d63',1,'API']]]
];
