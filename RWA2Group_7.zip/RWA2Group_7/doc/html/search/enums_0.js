var searchData=
[
  ['direction_96',['direction',['../util_8h.html#a99f26e6ee9fcd62f75203b5402df8098',1,'util.h']]]
];
