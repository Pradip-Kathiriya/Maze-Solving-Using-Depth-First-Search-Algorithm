var searchData=
[
  ['ackreset_0',['ackReset',['../class_a_p_i.html#a3e6a76df2da89bd7f7fc72a96e0a9094',1,'API']]],
  ['api_1',['API',['../class_a_p_i.html',1,'']]],
  ['api_2ecpp_2',['api.cpp',['../api_8cpp.html',1,'']]],
  ['api_2eh_3',['api.h',['../api_8h.html',1,'']]]
];
